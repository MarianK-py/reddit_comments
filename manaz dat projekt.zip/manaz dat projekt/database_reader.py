import sqlite3
from wordcloud import WordCloud


connection = sqlite3.connect('reddit_comments.sqlite3')

cursor = connection.cursor()

cursor.execute("SELECT * FROM posts")

cursor.execute("""SELECT comment FROM how_is_everyone_enjoying_reddit_while_instagram""")

#print(list(cursor))

text = ""
for i in list(cursor):
    text += i[0]


cursor.execute("""SELECT dateTim FROM how_is_everyone_enjoying_reddit_while_instagram""")
print(list(cursor))

# Generate a word cloud image
wordcloud = WordCloud(background_color="white").generate(text)

# Display the generated image:
# the matplotlib way:
import matplotlib.pyplot as plt
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis("off")

# lower max_font_size
wordcloud = WordCloud(max_font_size=50).generate(text)
plt.figure()
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.show()

connection.close()

#%%
