from flask import Flask, render_template, g
import sqlite3
import matplotlib.pyplot as plt
from wordcloud import WordCloud
import re

app = Flask(__name__)

## znaky ktore sa nepocitaju do dlzky odpovede
bad_chars = "[\(\)\,\.\[\]\-\_\:\;\/ ]"

## Spojenie s databazou
def con_db():
    return sqlite3.connect('reddit_comments.sqlite3')

@app.before_request
def before_request():
    g.db = con_db()

@app.teardown_request
def teardown_request(exc):
    db = getattr(g, 'db', None)
    if db is not None:
        db.close()

## Hlavna stranka s otazkami
@app.route("/")
def home():
    cur = g.db.cursor()
    ## Ziskanie otazok z hlavnej tabulky
    cur.execute("SELECT * FROM posts")

    ## Render hlavneho HTML dokumentu
    return render_template("main.html", posts=list(cur))

## Podstranka s otazkou
@app.route("/postPage/<postName>/")
def postPage(postName):
    cur = g.db.cursor()

    ## Zakladne informacie
    cur.execute(f"SELECT * FROM posts WHERE subtable == '{postName}'")
    aboutPost =list(cur)
    title = aboutPost[0][0].replace(" : AskReddit", "")
    url = aboutPost[0][1]

    ## Hlavne citanie z databazy
    cur.execute(f"SELECT * FROM '{postName}'")
    comments = list(cur)

    ## Histogram dlzok komentarov
    text = ""
    lengthOfComm = "[['Author', 'Length'], \n"
    for com in comments:
        text += com[2]
        lengthOfComm += f"['{com[0]}', {len(re.sub(bad_chars, '', com[2]))}], \n"
    lengthOfComm += "]"
    wholeLength = len(re.sub(bad_chars, '', text))
    avrLength = round(wholeLength/len(comments))

    ## Histogram casov komentarov
    timeOfcomm = "[['Author', 'DateTime'], \n"
    for com in comments:
        timeOfcomm += f"['{com[0]}', new Date('{com[3]}')], \n"
    timeOfcomm += "]"

    ## Histogram hodnoteni komentarov
    upvotesOfcomm = "[['Author', 'Upvotes'], \n"
    for com in comments:
        upvotesOfcomm += f"['{com[0]}', {com[1]}], \n"
    upvotesOfcomm += "]"

    ## Wordcloud komentarov
    wordcloud = WordCloud(background_color="#CCCCCC", max_font_size=100,
                          collocations=False, width=800, height=400).generate(text)
    plt.figure(facecolor="#CCCCCC", tight_layout=True, figsize=(8,4))
    plt.imshow(wordcloud, interpolation="bilinear")
    plt.axis("off")
    plt.savefig('static/wordcloud.png')

    ## Najlepsie komentare
    sortedComments = sorted(comments, key=lambda x: x[1], reverse=True)
    topComments = sortedComments[:3]

    ## Najlepsi autory
    cur.execute(f"SELECT author, COUNT(*), SUM(upvotes) FROM '{postName}' GROUP BY author")
    authors = list(cur)
    for i in authors:
        if "unknown" in i:
            authors.remove(i)
    sortedAuthors = sorted(authors, key=lambda x: x[2], reverse=True)
    topAuthors2 = sortedAuthors[:3]
    sortedAuthors = sorted(sortedAuthors, key=lambda x: x[1], reverse=True)
    topAuthors1 = sortedAuthors[:3]

    ## Render HTML dokumentu
    return render_template("post.html", comments=comments, title=title, url=url,
                           lengths=lengthOfComm, avr=avrLength, times=timeOfcomm, upvotes=upvotesOfcomm,
                           topCom=topComments, topAut1=topAuthors1, topAut2=topAuthors2)

if __name__ == "__main__":
    app.run(debug=True)