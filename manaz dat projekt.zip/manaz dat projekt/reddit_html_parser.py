import requests
from bs4 import BeautifulSoup
import sqlite3
import time


## Spojenie s databazou
connection = sqlite3.connect('reddit_comments.sqlite3')
cursor = connection.cursor()

## Ziskavanie otazok
def get_posts(subreddit, numberOfPages):
    ## Zoznam otazok
    comment_sections = []

    ## Startovaci cas a pocitadlo pokusov (nemaju velky vyznam)
    start = time.time()
    counter = 0

    ## Url prvej strany s otazkymi
    url = "https://old.reddit.com/r/"+subreddit+"/top/?sort=top&t=year"

    ## Cyklus spracujuci stany s otazkami
    for i in range(numberOfPages):
        ## citanie html suboru
        page = requests.get(url).text
        parsed = BeautifulSoup(page, 'html.parser')

        ## Kontrola ci nebol prekroceny maximalny pocet requestov
        while parsed.select("title")[0].text == "Too Many Requests":
            page = requests.get(url).text
            parsed = BeautifulSoup(page, 'html.parser')
            counter += 1

        ## Hladanie otazok
        entries = parsed.select('div.entry')

        ## Spracovanie otazok
        for entry in entries:
            a_with_url = entry.select("a.comments")[0]["href"]
            comment_sections.append(a_with_url)
        print(i+1)

        ## Dalsia strana s otazkami
        url = parsed.select("span.next-button a")[0]["href"]

    ## Nepodstatne veci/informacne printy
    print(time.time()-start)
    print(counter)

    ## Vratenie zoznamu s url pre otazky
    return comment_sections

## Ziskavanie odpovedi na otazku
def get_comment(url, name):
    ## Citanie html suboru
    page = requests.get(url+"?limit=500").text
    parsed = BeautifulSoup(page, 'html.parser')

    ## Nepodstatny counter
    counter = 1

    ## Kontrola ci nebol prekroceny maximalny pocet requestov
    while parsed.select("title")[0].text == "Too Many Requests":
        page = requests.get(url+"?limit=500").text
        parsed = BeautifulSoup(page, 'html.parser')
        counter += 1

    ## Hladanie odpovedi
    entries = parsed.select('div.commentarea div.entry')

    ## Nepodstatne veci/informacne printy
    print("Number of requests: ", counter)

    ## Vytvorenie tabulky pre otazku
    cursor = connection.cursor()
    cursor.execute(f"""
    CREATE TABLE IF NOT EXISTS {name} (
    author TEXT,
    upvotes INT,
    comment TEXT, 
    dateTim DATETIME)
    """)

    ## Ziskavanie udajov z odpovedi
    for entry in entries:
        ## Text odpovede
        text = "[deleted]"
        if entry.select("div.md") != []:
            text = entry.select("div.md")[0].text.strip()

        ## Autor odpovede
        author = "unknown"
        if entry.select("a.author") != []:
            author = entry.select("a.author")[0].text
            if author == "[deleted]":
                author = "unknown"

        ## Hodnotenie odpovede
        upvotes = 0
        if entry.select("span.unvoted") != []:
            temp = entry.select("span.unvoted")[0].text.split(" ")[0]
            if "k" in temp:
                upvotes = int(float(temp[:-1])*1000)
            else:
                upvotes = int(temp)

        ## Cas napisania odpovede
        time = ""
        if entry.select("time") != []:
            time = entry.select("time")[0]["datetime"]
            time = time.replace(time[-3:], "") + "00"

        ## Vlozenie odpovede do databazy
        if text != "[deleted]":
            cursor.execute(f"""INSERT INTO {name} (author, upvotes, comment, dateTim)
                                VALUES (?, ?, ?, ?)""", (author, upvotes, text, time))

    ## Vratenie nazvu otazky
    return parsed.select("title")[0].text

## Naplnanie databazy
def database_filler():
    ## Ziskanie zoznamu otazok
    posts_urls = get_posts("AskReddit", 20)

    ## Vytvorenie hlavnej tabulky s otazkami
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS posts (
    name TEXT,
    url TEXT,
    subtable TEXT)
    """)

    ## Nepodstatny timer
    start = time.time()

    ## Spracovanie jednotlivych otazok
    for i, post in enumerate(posts_urls):
        print(i+1)

        ## Nazov podtabulky
        subtable_name = post.split("/")[7]

        ## Spracovanie otazky
        name = get_comment(post, subtable_name)

        ## Vlozenie otazky do hlavnej tabulky
        cursor.execute("""INSERT INTO posts (name, url, subtable)
                            VALUES (?, ?, ?)""", (name, post, subtable_name))

        ## Update databazy
        connection.commit()

    ## Nepodstatne veci/informacne printy
    print(time.time() - start)
    ## Kontrolny update databazy
    connection.commit()

## Volanie funkcie na ziskanie dat
database_filler()

## Uzavretie databazy
connection.close()
